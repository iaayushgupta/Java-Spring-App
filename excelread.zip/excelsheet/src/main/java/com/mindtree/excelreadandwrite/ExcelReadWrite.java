package com.mindtree.excelreadandwrite;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.model.WorkbookRecordList;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mindtree.entity.MindDetail;

public class ExcelReadWrite {
	public static void main(String []args) {
//   List<MindDetail> mindtree = new ArrayList<MindDetail>();
//   mindtree.add(new MindDetail(1,"aayush",24000));
//   mindtree.add(new MindDetail(2,"anand",24000));
//   mindtree.add(new MindDetail(3,"srishty",24000));
//   
//   XSSFWorkbook workbook = new XSSFWorkbook();
//   XSSFSheet sheet = workbook.createSheet("mind details");
//   int rownum=0;
//   for( MindDetail minddetail:mindtree) {
//	   Row row = sheet.createRow(rownum++);
//	   Cell cell1 = row.createCell(0);
//	   cell1.setCellValue(minddetail.getMindId());
//	   Cell cell2 = row.createCell(1);
//	   cell2.setCellValue(minddetail.getMindName());
//	   Cell cell3 = row.createCell(2);
//	   cell3.setCellValue(minddetail.getMindsalary());
//   }
//   File file = new File("D:/excelsheet/mindtreedetail.xlsx");
//   try {
//	FileOutputStream fos = new FileOutputStream(file);
//	workbook.write(fos);
//	
//	fos.close();
//	workbook.close();
//} catch (IOException e) {
//	// TODO Auto-generated catch block
//	System.out.println(e.getMessage());
//}
		try {
			FileInputStream fis = new FileInputStream("D:/excelsheet/mindtreedetail.xlsx");
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet("mind details");
			Iterator<Row> rowiter = sheet.iterator();
			while(rowiter.hasNext()) {
				Row rownext =rowiter.next(); 
				Iterator<Cell> celliterator = rownext.iterator();
				while(celliterator.hasNext()) {
					Cell cell = celliterator.next();
					switch(cell.getCellType()) {
					case Cell.CELL_TYPE_NUMERIC:
						System.out.println(cell.getNumericCellValue());
					break;
					case Cell.CELL_TYPE_STRING:
						System.out.println(cell.getStringCellValue());
						break;
					}
					System.out.println();
				}
				
			}
			workbook.close();
			fis.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
	}
}
