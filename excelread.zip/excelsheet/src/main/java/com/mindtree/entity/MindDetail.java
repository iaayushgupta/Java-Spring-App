package com.mindtree.entity;

public class MindDetail {
private int mindId;
private String mindName;
private float mindsalary;

public MindDetail(int mindId, String mindName, float mindsalary) {
	super();
	this.mindId = mindId;
	this.mindName = mindName;
	this.mindsalary = mindsalary;
}
public int getMindId() {
	return mindId;
}
public void setMindId(int mindId) {
	this.mindId = mindId;
}
public String getMindName() {
	return mindName;
}
public void setMindName(String mindName) {
	this.mindName = mindName;
}
public float getMindsalary() {
	return mindsalary;
}
public void setMindsalary(float mindsalary) {
	this.mindsalary = mindsalary;
}
}
