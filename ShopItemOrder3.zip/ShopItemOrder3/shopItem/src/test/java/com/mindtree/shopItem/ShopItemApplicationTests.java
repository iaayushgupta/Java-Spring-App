package com.mindtree.shopItem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
