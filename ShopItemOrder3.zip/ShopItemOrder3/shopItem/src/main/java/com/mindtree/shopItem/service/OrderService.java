package com.mindtree.shopItem.service;

import com.mindtree.shopItem.entity.Orders;

public interface OrderService {

	Orders addOrder(Orders order);

	String assignOrder(int shopId, int orderId, int itemId);

}
