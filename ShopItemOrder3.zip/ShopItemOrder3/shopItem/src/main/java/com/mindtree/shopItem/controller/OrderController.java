package com.mindtree.shopItem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.shopItem.entity.Orders;
import com.mindtree.shopItem.service.OrderService;

@RestController
public class OrderController {

	
	

	@Autowired
	private OrderService orderService;

	@PostMapping("/addorder")
	public Orders addOrder(@RequestBody Orders order) {
		return orderService.addOrder(order);
	}

	@PutMapping("/assign/{shopId}/{orderId}/{itemId}")
	public String assignMovie(@PathVariable int shopId, @PathVariable int orderId, @PathVariable int itemId) {

		return orderService.assignOrder(shopId, orderId, itemId);
	}
}
