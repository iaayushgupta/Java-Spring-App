package com.mindtree.shopItem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopItemApplication.class, args);
	}

}
