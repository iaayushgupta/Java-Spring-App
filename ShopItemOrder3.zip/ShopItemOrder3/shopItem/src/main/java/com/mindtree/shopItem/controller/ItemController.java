package com.mindtree.shopItem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.shopItem.entity.Item;
import com.mindtree.shopItem.service.ItemService;

@RestController
public class ItemController {

	@Autowired
	private ItemService itemService;

	@PostMapping("/addItem")
	public Item addItem(@RequestBody Item item) {
		return itemService.addItem(item);
	}
}
