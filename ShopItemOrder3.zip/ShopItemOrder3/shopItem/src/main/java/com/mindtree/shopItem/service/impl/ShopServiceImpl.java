package com.mindtree.shopItem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.shopItem.entity.Orders;
import com.mindtree.shopItem.entity.Shop;
import com.mindtree.shopItem.exception.ServiceException;
import com.mindtree.shopItem.exception.ShopAlreadyPresent;
import com.mindtree.shopItem.repository.ShopRepository;
import com.mindtree.shopItem.service.ShopService;

@Service
public class ShopServiceImpl implements ShopService {

	@Autowired
	private ShopRepository shopRepository;

	@Override
	public Shop addShop(Shop shop) {
		// TODO Auto-generated method stub
     return shopRepository.save(shop);

	}

}
