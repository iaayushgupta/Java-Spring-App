package com.mindtree.shopItem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.shopItem.dto.ResponseDto;
import com.mindtree.shopItem.entity.Item;
import com.mindtree.shopItem.entity.Shop;
import com.mindtree.shopItem.exception.ApplicationException;
import com.mindtree.shopItem.service.ShopService;

@RestController
public class ShopController {

	@Autowired
	private ShopService shopService;

	@PostMapping("/addShop")
	public Shop addShop(@RequestBody Shop shop) {
        return shopService.addShop(shop);

	}

}
