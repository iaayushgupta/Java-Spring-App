package com.mindtree.shopItem.service;

import com.mindtree.shopItem.entity.Item;

public interface ItemService {

	Item addItem(Item item);

}
