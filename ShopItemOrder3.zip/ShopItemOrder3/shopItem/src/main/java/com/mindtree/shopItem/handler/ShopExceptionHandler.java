package com.mindtree.shopItem.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.shopItem.dto.ErrorDto;
import com.mindtree.shopItem.exception.ApplicationException;

@RestControllerAdvice
public class ShopExceptionHandler {

		
	

	@ExceptionHandler(ApplicationException.class)
	public ResponseEntity<?> errorHandler(Exception ex) {
		return new ResponseEntity<ErrorDto>(new ErrorDto(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, 500, true),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> errorHandler1(MethodArgumentNotValidException ex) {
		return new ResponseEntity<ErrorDto>(new ErrorDto(ex.getMessage(), HttpStatus.NOT_FOUND, 400, true),
				HttpStatus.NOT_FOUND);
	}
//	@ExceptionHandler(ApplicationException.class)
//	public ResponseEntity<?> errorHandler1(Exception ex) {
//		return new ResponseEntity<ErrorDto>(new ErrorDto(ex.getMessage(), HttpStatus.NOT_FOUND, 400, true),
//				HttpStatus.NOT_FOUND);
//	}
//	@ExceptionHandler(MethodArgumentNotValidException.class)
//	public ResponseEntity<?> errorHandler(MethodArgumentNotValidException ex) {
//		return new ResponseEntity<ErrorDto>(new ErrorDto(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, 500, true),
//				HttpStatus.INTERNAL_SERVER_ERROR);
//	}
}
