package com.mindtree.shopItem.service;

import com.mindtree.shopItem.entity.Shop;
import com.mindtree.shopItem.exception.ServiceException;

public interface ShopService {

	Shop addShop(Shop shop);

}
