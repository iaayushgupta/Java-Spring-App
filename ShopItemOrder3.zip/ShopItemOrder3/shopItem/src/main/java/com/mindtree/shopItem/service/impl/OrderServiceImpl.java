package com.mindtree.shopItem.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.shopItem.entity.Item;
import com.mindtree.shopItem.entity.Orders;
import com.mindtree.shopItem.entity.Shop;
import com.mindtree.shopItem.repository.ItemRepository;
import com.mindtree.shopItem.repository.OrderRepository;
import com.mindtree.shopItem.repository.ShopRepository;
import com.mindtree.shopItem.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private ItemRepository itemRepository;

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private ShopRepository shopRepository;

	@Override
	public Orders addOrder(Orders order) {
		// TODO Auto-generated method stub
		return orderRepository.save(order);
	}

	@Override
	public String assignOrder(int shopId, int orderId, int itemId) {
		// TODO Auto-generated method stub

		Orders order = orderRepository.findById(orderId).get();
		Shop shop = shopRepository.findById(shopId).get();
		Item item = itemRepository.findById(itemId).get();
		order.getItems().add(item);
		int totalAmt = order.getTotalAmt();
		totalAmt = totalAmt + item.getPrice();
		order.setTotalAmt(totalAmt);
		item.getOrders().add(order);
		for (Orders order1 : shop.getOrders()) {
			if (order1.getOrderId() == order.getOrderId()) {
				shop.setTotalOrders(shop.getOrders().size());
				order.setShop(shop);
				orderRepository.save(order);
				itemRepository.save(item);
				return "Succefully Assigned";
			}
		}
		shop.getOrders().add(order);
		shop.setTotalOrders(shop.getOrders().size());
		order.setShop(shop);
		orderRepository.save(order);
		itemRepository.save(item);
		shopRepository.save(shop);
		return "Succefully Assigned";
	}

}
