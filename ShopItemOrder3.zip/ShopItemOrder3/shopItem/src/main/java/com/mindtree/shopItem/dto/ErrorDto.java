package com.mindtree.shopItem.dto;

import org.springframework.http.HttpStatus;

public class ErrorDto {

	private String message2;
	private HttpStatus status;
	private int httpStatusCode;
	private boolean error;

	public ErrorDto(String message2, HttpStatus badRequest, int httpStatusCode, boolean value) {

		// TODO Auto-generated constructor stub
		this.message2 = message2;
		this.status = badRequest;
		this.httpStatusCode = httpStatusCode;
		this.error = value;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public int getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}
}
