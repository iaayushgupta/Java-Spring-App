package com.mindtree.shopItem.dto;

import org.springframework.http.HttpStatus;

public class ResponseDto<T> {

	private T response;

	private HttpStatus status;

	private int code;

	public ResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResponseDto(T response, HttpStatus status, int code) {
		super();
		this.response = response;
		this.status = status;
		this.code = code;
	}

	public T getResponse() {
		return response;
	}

	public void setResponse(T response) {
		this.response = response;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
}
